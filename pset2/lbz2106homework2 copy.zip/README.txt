Laura Zhang lbz2106

1. MyStack.java implements a stack using an arraylist as an initialized variable. This file should be compiled with "javac MyStack.java".

2. SymbolBalance.java creates a stack that is used to catch mismatched brackets and quotation marks, missing brackets or quotation marks, or extra brackets or quotation marks. The stack class used is MyStack.java. This file should be compiled with "javac SymbolBalance.java" and should be run with "java SymbolBalance Testfile.java" with the testfile being any text source of your choosing. 

3. TwoStackQueue.java implements a queue using two stacks that use MyStack.java. Enqueueing and Dequeueing involve shifting values from one stack to another in order to place values in the right order. This file should be compiled with "javac TwoStackQueue.java".

4. Program2.java creates a test file to check the queueing functions of TwoStackQueue. The output should be the following: 
Roses
Peonies
Daisies
Chrysanthemums
Dandelions
0
null
Sunflowers
This file should be compiled with "javac Program2.java" and run with "java Program2". 